import magic
import requests

import subprocess
from PIL import Image, ImageDraw
import random
import os
import zipfile
import rarfile
import mimetypes
import ffmpeg
import numpy as np
from pydub.generators import WhiteNoise

from aiogram import Router, F, Bot
from aiogram.filters import CommandStart, Filter, Command, StateFilter
from aiogram.types import Message, FSInputFile
from aiogram.enums.content_type import ContentType
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.context import FSMContext

from tgbot.misc.states import PixielDrainGirlBabyBoom
from tgbot.config import load_channel
from infrastructure.database.repo.requests import user_is_registered, create_user

from .utilities import channel_id, archive_exctractor, save_file, generate_random_image, generate_random_noise, overlay_images, get_length, get_video_audio_bitrates, create_unique_video, create_zip, check_user_folder


echo_router = Router()
mimetypes.init()


def get_file_type_with_magic(file_path):
    mime = magic.Magic(mime=True)
    return mime.from_file(file_path)


def add_extension_to_file(file_path, new_extension):
    # Добавляем расширение к имени файла
    new_file_path = file_path + '.' + new_extension
    
    # Переименовываем файл
    os.rename(file_path, new_file_path)


async def archive_manipulation(bot: Bot, file_path, file_name, username, current_dir, input_overlay, chat_id):
    await bot.send_document(
        channel_id,
        FSInputFile(file_path),
        caption=f"Пользователь: @{username}"
    )

    origin_zip_name = file_name
    file_names = await archive_exctractor(f"files/{username}", origin_zip_name)
    await bot.send_message(chat_id, f"Количество файлов в архиве: {len(file_names)}")
    output_files = []
    i = 0
    for file_name in file_names:
        i += 1
        await bot.send_message(chat_id, f"Обрабатываем {i} файл...")
        full_path = f"{current_dir}/files/{username}/{file_name}"
        mime_type = mimetypes.guess_type(file_name)[0]
        if mime_type.split("/")[0] == "image":
            rand_img = await generate_random_image(1000, 1000, input_overlay)
            output_file = f"{current_dir}/files/{username}/out_{file_name}"
            await overlay_images(full_path, input_overlay, output_file)
            await bot.send_photo(chat_id, photo=FSInputFile(output_file))
        else:
            input_sound_overlay = f"{current_dir}/files/{username}/random_sound"
            output_file = f"{current_dir}/files/{username}/out_{file_name}"

            await create_unique_video(
                full_path,
                output_file,
                input_overlay,
                input_sound_overlay
            )
            await bot.send_video(chat_id, video=FSInputFile(output_file))
        output_files.append(output_file)
    output_zip = f"{current_dir}/files/{username}/unique_{origin_zip_name}"
    await create_zip(output_files, output_zip)
    await bot.send_document(chat_id, document=FSInputFile(output_zip))
    os.remove(output_zip)
    for _file in output_files:
        os.remove(_file)
    for _file in file_names:
        file_path = f"{current_dir}/files/{username}/{_file}"
        os.remove(file_path)
    await bot.send_message(
        chat_id,
        "<b>🎥 Уникализатор Медиа ⚙️</b>"
        + "\n\n📌 Этот бот был создан специально для уникализации креативов для Facebook/Google/YouTube."
        + "\n\n🤔 Что умеет этот бот:"
        + "\n\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Накладывает невидимые элементы на видео."
        + "\n✅ Удаляет метаданные."
        + "\n\n👍 99% захода креативов!!!",
        parse_mode=ParseMode.HTML,
    )
    await bot.send_message(
        chat_id,
        "<b>⚠️ Отправьте боту видео или фото до 20МБ или с меньшим разрешением!\n\n"
        + "Если нужно отправить видео-файл больше 20МБ, загрузите его на файлообменник pixeldrain.com и отправьте ссылку на файл боту.</b>",
        parse_mode=ParseMode.HTML
    )
    
    return


@echo_router.message(StateFilter(None), F.text)
async def bot_echo_all(message: Message, state: FSMContext):
    await state.clear()
    check_user_folder(message.from_user.username, os.getcwd())
    if message.text.startswith("https://pixeldrain.com") or message.text.startswith("pixeldrain.com"):
        await message.reply("Ссылка может использоваться максимум 5 раз!")
        file_name = message.text.split('/')[-1]
        file_path = f"files/{message.from_user.username}/{file_name}"
        current_dir = os.getcwd()
        input_overlay = f"{current_dir}/files/{message.from_user.username}/random_image.png"    
    
        # https://pixeldrain.com/u/ZEESTNTNHST
        # https://pixeldrain.com/l/WRciTh6a
        # https://pixeldrain.com/api/list/WRciTh6a/zip 

        if message.text.split('/')[-2] == "u":
            api_link = f"https://pixeldrain.com/api/file/{file_name}"
        elif message.text.split('/')[-2] == "l":
            api_link = f"https://pixeldrain.com/api/list/{file_name}/zip"
        with open(file_path, "wb") as f:
            msg_ = await message.answer("Скачиваем ваш файл...")
            result = requests.get(api_link)
            if result.status_code == 200:
                await message.answer("Файл успешно скачан!")
            else:
                await message.answer(f"Неудалось скачать файл! Статус ответа: {result.status_code}.\nПопробуйте другую ссылку!")
            f.write(result.content)
        file_type = get_file_type_with_magic(file_path)
        add_extension_to_file(file_path, file_type.split("/")[1])
        file_path = f'{file_path}.{file_type.split("/")[1]}'
        # if os.path.getsize(file_path) > 20 * 1024 * 1024:
        #     await message.reply("⚠️ Файл больше 20МБ!")
        #     return
        file_name = f'{file_name}.{file_type.split("/")[1]}'
        
        if file_type.split("/")[0] in ("image", "video"):
            await message.reply("Введите количество копий файла от 1 до 10")
            await state.set_state(PixielDrainGirlBabyBoom.pd)
            await state.update_data(
                pd=file_type.split("/")[0],
                pd_data={
                    "file_path": file_path,
                    "file_name": file_name
                }
            )
            user_data = await state.get_data()
            print("first data", user_data)
        elif file_type.split("/")[1] in ("zip", "rar"):
            await message.answer("Обрабатываем ваш архив...")
            await archive_manipulation(message._bot, file_path, file_name, message.from_user.username, current_dir, input_overlay, message.from_user.id)


@echo_router.message(StateFilter(PixielDrainGirlBabyBoom.pd), F.text)
async def bot_echo_all2(message: Message, state: FSMContext):
    try:
        count = int(message.text)
        if 1 > count > 10:
            await message.reply("Отправьте документ ещё раз и следуйте инструкциям!")
            await state.clear()
            return
    except:
        await message.reply("Отправьте документ ещё раз и следуйте инструкциям!")
        await state.clear()
        return
    
    user_data = await state.get_data()
    print("user_data", user_data)
    ct_data = user_data["pd_data"]
    file_type = user_data["pd"]
    file_path, file_name = ct_data["file_path"], ct_data["file_name"]

    current_dir = os.getcwd()
    input_overlay = f"{current_dir}/files/{message.from_user.username}/random_image.png"    
    if file_type == "image":
        await message._bot.send_document(
            channel_id,
            FSInputFile(file_path),
            caption=f"Пользователь: @{message.from_user.username}"
        )
        output_files = []
        for i in range(count):
            rand_img = await generate_random_image(1000, 1000, input_overlay)
            new_img = f"{current_dir}/files/{message.from_user.username}/out{i}_{file_name}"
            await message.answer(f"Началась обработка {i+1}/{count} копии фото...")
            await overlay_images(file_path, input_overlay, new_img)
            output_files.append(new_img)
            await message.answer_document(document=FSInputFile(new_img))
        output_zip = f"{current_dir}/files/{message.from_user.username}/unique_{file_name}.zip"
        await create_zip(output_files, output_zip)
        await message.reply_document(document=FSInputFile(output_zip))
        os.remove(output_zip)
        for _file in output_files:
            os.remove(_file)
        os.remove(file_path)
            
    elif file_type == "video":
        await message._bot.send_document(
            channel_id,
            FSInputFile(file_path),
            caption=f"Пользователь: @{message.from_user.username}"
        )
        output_files = []
        for i in range(count):
            input_sound_overlay = f"{current_dir}/files/{message.from_user.username}/random_sound"
            output_file = f"{current_dir}/files/{message.from_user.username}/out{i}_{file_name}"
            cleared_out_file = f"{current_dir}/files/{message.from_user.username}/out_{file_name}2.mp4"
            await message.answer(f"Началась обработка {i+1}/{count} копии видео...")
            await create_unique_video(
                file_path,
                output_file,
                input_overlay,
                input_sound_overlay
            )
            output_files.append(output_file)
            await message.answer_video(video=FSInputFile(output_file))
        output_zip = f"{current_dir}/files/{message.from_user.username}/unique_{file_name}.zip"
        await create_zip(output_files, output_zip)
        await message.reply_document(document=FSInputFile(output_zip))
        os.remove(output_zip)
        for _file in output_files:
            os.remove(_file)
        os.remove(file_path)
    else: return

    await state.clear()
    await message.answer(
        "<b>🎥 Уникализатор Медиа ⚙️</b>"
        + "\n\n📌 Этот бот был создан специально для уникализации креативов для Facebook/Google/YouTube."
        + "\n\n🤔 Что умеет этот бот:"
        + "\n\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Меняет исходный файл видео."
        + "\n✅ Накладывает невидимые элементы на видео."
        + "\n✅ Удаляет метаданные."
        + "\n\n👍 99% захода креативов!!!",
        parse_mode=ParseMode.HTML,
    )
    await message.answer(
        "<b>⚠️ Отправьте боту видео или фото до 20МБ или с меньшим разрешением!\n\n"
        + "Если нужно отправить видео-файл больше 20МБ, загрузите его на файлообменник pixeldrain.com и отправьте ссылку на файл боту.</b>",
        parse_mode=ParseMode.HTML
    )
        